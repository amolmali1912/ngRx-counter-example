export const initialState = {
    counter: 0
}